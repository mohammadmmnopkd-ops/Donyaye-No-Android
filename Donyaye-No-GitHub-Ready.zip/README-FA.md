# دنیای نو — Android + Server

این بسته شامل:
- پروژه کامل Android Studio
- نسخه HTML بازی داخل `app/src/main/assets/index.html`
- سرور Node.js در پوشه `server`
- اتصال API بازی به سرور آنلاین

## ساخت APK
Android Studio را نصب کنید، پروژه را باز کنید و:
Build > Build APK(s)

## آدرس سرور
در HTML، آدرس پیش‌فرض سرور روی:
https://donyaye-no-online.onrender.com
قرار گرفته است.

اگر سرور را جابه‌جا کردید، مقدار `window.DONYAYE_NO_API_BASE` در ابتدای HTML را تغییر دهید.

## نکته
در این محیط Android SDK/Gradle distribution موجود نبود؛ بنابراین APK باینری قابل تست اینجا ساخته نشده و فایل تحویلی یک پروژه واقعی Android Studio قابل Build است.
